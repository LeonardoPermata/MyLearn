﻿using _44100_LeonardoGS.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using MySql.Data.MySqlClient;
using System.Diagnostics;
using System.Security.Cryptography;

namespace _44100_LeonardoGS.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly MyGlobalVariable _MyGlobalVariable;

        public HomeController(ILogger<HomeController> logger,
            IOptions<MyGlobalVariable> myGlobalVariable)
        {
            _logger = logger;
            _MyGlobalVariable = myGlobalVariable.Value;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult PartialViewAction()
        {
            ViewBag.message = "This is a message from controller";
            return PartialView("PartialView1");
        }

        //Insert Data User View
        public IActionResult Register()
        {
            return View();
        }

        //Insert Data User to Database
        [HttpPost]
        public IActionResult RegisterAction(RegisterModel mdl)
        {
            if (ModelState.IsValid)
            {
                string constr = _MyGlobalVariable.MySqlConString;
                if(constr != null)
                {
                    string query = "INSERT INTO user (username, password, Name, Gender) VALUES (@username, @password, @name, @gender);";
                    using (MySqlConnection con = new MySqlConnection(constr))
                    {
                        using (MySqlCommand cmd = new MySqlCommand(query))
                        {
                            cmd.Connection = con;
                            con.Open();
                            cmd.Parameters.AddWithValue("@username", mdl.Username);
                            cmd.Parameters.AddWithValue("@password", mdl.Password);
                            cmd.Parameters.AddWithValue("@name", mdl.Name);
                            cmd.Parameters.AddWithValue("@gender", mdl.Gender);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            ViewBag.RegisterStatus = $"User {mdl.Username} Successfully Register";
            return View("Index");
        }

        //Update Data User View
        public IActionResult UpdateUser(Int64 id)
        {
            RegisterModel rgsUser = new RegisterModel();
            string constr = _MyGlobalVariable.MySqlConString;
            if(constr != null)
            {
                string query = "SELECT ID, username, password, Name, Gender WHERE ID = " + id +" LIMIT 1;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();
                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                rgsUser.Id = Convert.ToInt64(sdr["ID"]);
                                rgsUser.Username = sdr["username"].ToString();
                                rgsUser.Password = sdr["password"].ToString();
                                rgsUser.Name = sdr["Name"].ToString();
                                rgsUser.Gender = sdr["Gender"].ToString();
                            }
                        }
                        con.Close();
                    }
                }
            }
            return View(rgsUser);
        }

        //Update Data User Action to Database
        public IActionResult ActionUpdateUser(RegisterModel mdl)
        {
            if (ModelState.IsValid)
            {
                string constr = _MyGlobalVariable.MySqlConString;
                if (constr != null)
                {
                    string query = "UPDATE user SET username = @username, password = @password, Name = @name, Gender = @gender WHERE ID = @Id;";
                    using (MySqlConnection con = new MySqlConnection(constr))
                    {
                        using (MySqlCommand cmd = new MySqlCommand(query))
                        {
                            cmd.Connection = con;
                            con.Open();
                            cmd.Parameters.AddWithValue("@username", mdl.Username);
                            cmd.Parameters.AddWithValue("@password", mdl.Password);
                            cmd.Parameters.AddWithValue("@name", mdl.Name);
                            cmd.Parameters.AddWithValue("@gender", mdl.Gender);
                            cmd.Parameters.AddWithValue("@id", mdl.Id);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            ViewBag.RegisterStatus = $"User {mdl.Username} Successfully Updated";
            return View("Index");
        }

        //Delete Data User
        public IActionResult DeleteUser(Int64 id)
        {
            RegisterModel rgsUser = new RegisterModel();
            string constr = _MyGlobalVariable.MySqlConString;
            if(constr != null)
            {
                string query = "SELECT ID, username, password, Name, Gender WHERE ID = " + id + " LIMIT 1;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();
                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                rgsUser.Username = sdr["username"].ToString();
                                rgsUser.Password = sdr["password"].ToString();
                                rgsUser.Name = sdr["name"].ToString();
                                rgsUser.Gender = sdr["gender"].ToString();
                            }
                        }
                        con.Close();
                    }
                }
            }
            return View(rgsUser);
        }

        //Delete Data User Action to Database
        public IActionResult ActionDeleteUser(RegisterModel rgs)
        {
            if(rgs.Id != 0)
            {
                string constr = _MyGlobalVariable.MySqlConString;
                if(constr != null)
                {
                    string query = "DELETE FROM user WHERE Id = @Id;";
                    using (MySqlConnection con = new MySqlConnection(constr))
                    {
                        using (MySqlCommand cmd = new MySqlCommand(query))
                        {
                            cmd.Connection = con;
                            con.Open();
                            cmd.Parameters.AddWithValue("@id", rgs.Id);
                            cmd.ExecuteNonQuery();
                            con.Close();
                        }
                    }
                }
            }
            ViewBag.RegisterStatus = $"User {rgs.Username} Successfully Deleted";
            return View("Index");
        }

        public IActionResult GetListUser()
        {
            List<RegisterModel> loginuser = new List<RegisterModel>();
            string constr = _MyGlobalVariable.MySqlConString;
            if (constr != null)
            {
                string query = "SELECT ID, username, password, Name, Gender FROM user;";
                using (MySqlConnection con = new MySqlConnection(constr))
                {
                    using (MySqlCommand cmd = new MySqlCommand(query))
                    {
                        cmd.Connection = con;
                        con.Open();
                        using (MySqlDataReader sdr = cmd.ExecuteReader())
                        {
                            while (sdr.Read())
                            {
                                loginuser.Add(new RegisterModel
                                {
                                    Id = Convert.ToInt64(sdr["ID"]),
                                    Username = sdr["username"].ToString(),
                                    Password = sdr["password"].ToString(),
                                    Name = sdr["Name"].ToString(),
                                    Gender = sdr["Gender"].ToString()
                                });
                            }
                        }
                        con.Close();
                    }
                }
            }
            return View(loginuser);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}